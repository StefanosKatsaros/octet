﻿using UnityEngine;
using System.Collections;
using System.IO;

public class reader : MonoBehaviour
{

    string x;

    void OnCollisionEnter(Collision col)
    {

        if (col.gameObject.name == "hitMe")
        {
            ReadFromFile();
        }
    }

    private void ReadFromFile()
    {
        StreamReader reader = new StreamReader("readMe.txt");
        x = reader.ReadLine();
        Debug.Log(x);
    }
}
