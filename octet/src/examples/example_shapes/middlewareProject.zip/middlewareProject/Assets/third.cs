﻿using UnityEngine;
using System.Collections;

public class third : MonoBehaviour
{
    public Texture2D textureToDisplay;
    private bool here = false;
    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.name == "3ball")
        {
            here = true;
        }
       
    }
    void Update()
    {   
        if(here == true && Time.timeScale >0.006) {
            Time.timeScale = Time.timeScale - 0.006F;
    }
       
    }

    void OnGUI()
    {
        if (here == true && Time.timeScale <= 0.006) { 
        GUI.Label(new Rect(0, 40, textureToDisplay.width, textureToDisplay.height), textureToDisplay);
            Time.timeScale = 0.0F;
        }
    }
}
