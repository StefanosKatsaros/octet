﻿using UnityEngine;
using System.Collections;

public class destroyScript : MonoBehaviour
{
    public GameObject other;
    

    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.name == "destroyMe")
        {
            Destroy(col.gameObject);
        }

        if (col.gameObject.name == "finisher")
        {
            other.AddComponent<Rigidbody>().AddForce(1,1,1);
        }
    }
}