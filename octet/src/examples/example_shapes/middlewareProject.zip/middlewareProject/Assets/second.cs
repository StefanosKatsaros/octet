﻿using UnityEngine;
using System.Collections;

public class second : MonoBehaviour
{
    public GameObject other;


    void OnCollisionEnter(Collision col)
    {     

        if (col.gameObject.name == "2nd")
        {
            other.AddComponent<Rigidbody>().AddForce(1, 1, 1);
        }
    }
}